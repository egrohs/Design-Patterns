package padroesestruturais.semfacade;


public class Aplicacao {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Aplicacao ap = new Aplicacao();
		ap.exibirMenu();
	}

	public void exibirMenu() {
		System.out.println("Metodo grande e complexo.");
	}
}
