package padroescomportamentais.chainofresponsibility;

public interface IFilter {
	public Object filter(Input i);
//	public void filter(float i);
//	public void filter(double i);
//	public void filter(String i);
}
