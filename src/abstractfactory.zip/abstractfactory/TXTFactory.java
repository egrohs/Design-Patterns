package abstractfactory;

public class TXTFactory extends DOCFactory {

}
