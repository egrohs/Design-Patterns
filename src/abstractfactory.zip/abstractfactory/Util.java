package abstractfactory;

public class Util {
	public enum TIPOS {
		BMP, JPG, GIF, TXT, PPT, XLS;
	}
}
