package abstractfactory;

public class PPTFactory extends DOCFactory{

}
