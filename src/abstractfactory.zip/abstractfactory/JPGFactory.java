package abstractfactory;

public class JPGFactory extends IMGFactory {

}
