package abstractfactory;

public class GIFFactory extends IMGFactory{

}
