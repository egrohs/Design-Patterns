package abstractfactory;

public class BMPFactory extends IMGFactory {

}
