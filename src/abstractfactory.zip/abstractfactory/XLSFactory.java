package abstractfactory;

public class XLSFactory extends DOCFactory {

}
