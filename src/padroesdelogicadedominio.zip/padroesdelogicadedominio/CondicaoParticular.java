package padroesdelogicadedominio;

public class CondicaoParticular extends CondicaoGeral {
	public CondicaoParticular(Proposta proposta) {
		super(proposta);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean permitirPagamento() {
		return super.permitirPagamento();
	}
}
