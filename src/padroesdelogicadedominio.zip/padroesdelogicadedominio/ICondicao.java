package padroesdelogicadedominio;

public interface ICondicao {
	public boolean permitirPagamento();
}
